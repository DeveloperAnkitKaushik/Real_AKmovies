import React from 'react'

const loading = () => {
  return (
    <div className='loadingcontainer'>
        <div className="found">
            <img src="/found.png" alt="" />
        </div>
    </div>
  )
}

export default loading